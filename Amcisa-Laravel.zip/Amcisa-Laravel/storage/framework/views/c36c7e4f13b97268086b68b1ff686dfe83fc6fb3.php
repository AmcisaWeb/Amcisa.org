<div>
    Please click this link to reset your password:
    <?php echo e($link); ?>

</div>