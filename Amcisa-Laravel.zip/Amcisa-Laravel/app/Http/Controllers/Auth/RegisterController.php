
<?php

//We don't use Laravel register functionality