function deleteitem(id) {
    var confirmbox = confirm('Are you sure you want to delete this entry?');
    if (confirmbox) {
        $.ajax({
            type: 'POST',
            url: 'php/delete.php',
            data: { id: id },
            method: "POST",
            success: function(response) {
                if (response == "fail") {
                    alert('Failed to delete');
                } else if (response == "done") {
                    window.location.reload();
                } else if (response == "timeup") {
                    alert('You are not allowed to make any deletions!');
                } else {
                    alert('Failed to delete');
                }
            }
        })
    }
}

$.ajax({
    type: 'POST',
    url: 'php/purchaselist.php',
    success: function(response) {
        if (response == "fail") {
            results = [{ toName: 'Error: request failed' }];
        } else {
            results = JSON.parse(response);
        }
        // Vue app
        table = new Vue({
            el: '#table',
            data: {
                results: results
            },
            methods: {
                refresh: function() {
                    $.ajax({
                        type: 'POST',
                        url: 'php/purchaselist.php',
                        success: function(response) {
                            if (response == "fail") {
                                results = [{ toName: 'Error: request failed' }];
                            } else {
                                results = JSON.parse(response);
                            }
                        }
                    })
                }
            }
        })
        $('.loader').addClass('hidden-xs-up');
        $('#form').removeClass('hidden-xs-up');
    }
})