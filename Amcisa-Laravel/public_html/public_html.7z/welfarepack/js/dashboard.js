// query url
var QueryString = function() {
    // This function is anonymous, is executed immediately and 
    // the return value is assigned to QueryString!
    var query_string = {};
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        // If first entry with this name
        if (typeof query_string[pair[0]] === "undefined") {
            query_string[pair[0]] = decodeURIComponent(pair[1]);
            // If second entry with this name
        } else if (typeof query_string[pair[0]] === "string") {
            var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
            query_string[pair[0]] = arr;
            // If third or later entry with this name
        } else {
            query_string[pair[0]].push(decodeURIComponent(pair[1]));
        }
    }
    return query_string;
}();

if (QueryString.lowlim != null) {
    var lowlim = QueryString.lowlim;
} else {
    var lowlim = 0;
}
if (QueryString.type != null) {
    var type = QueryString.type;
} else {
    var type = 0;
}
if (QueryString.hall != null) {
    var hall = QueryString.hall;
} else {
    var hall = 0;
}

// complete delivery order ajax
function complete(id) {
    $.ajax({
        method: 'POST',
        url: 'php/dashboardlist.php?type=complete',
        data: { id: id },
        success: function(response) {
            if (response == "fail") {
                alert('Operation failed');
            } else if (response == "done") {
                alert('Completed order id ' + id + '!');
                window.location.reload();
            } else {
                alert('Operation failed');
            }
        }
    })
}

// uncomplete delivery order ajax
function uncomplete(id) {
    $.ajax({
        method: 'POST',
        url: 'php/dashboardlist.php?type=uncomplete',
        data: { id: id },
        success: function(response) {
            if (response == "fail") {
                alert('Operation failed');
            } else if (response == "done") {
                alert('Undo complete for order id ' + id + '!');
                window.location.reload();
            } else {
                alert('Operation failed');
            }
        }
    })
}

// add transaction ajax
function addpayment(id, amt, matric, name) {
    $.ajax({
        method: 'POST',
        url: 'php/dashboardlist.php?type=insertPayment',
        data: {
            id: id,
            paid: amt,
            Matric_NO: matric,
            name: name
        },
        success: function(response) {
            if (response == "fail") {
                alert('Add transaction failed');
            } else if (response == "done") {
                alert('Added transaction of $' + amt + ' for ' + name);
                window.location.reload();
            } else {
                alert(response);
            }
        }
    })
}

function ready() {
    $('.loader').addClass('hidden-xs-up');
    $('#main').removeClass('hidden-xs-up');
}

// dashboard.html and paymentinfo.html
if (window.location.href.includes("http://amcisa.org/form/dashboard.html") || window.location.href.includes("http://amcisa.org/form/paymentinfo.html")) {
    // full payment list ajax
    $.ajax({
        type: 'GET',
        url: 'php/dashboardlist.php',
        data: { type: 'payment' },
        success: function(response) {
            if (response == "fail") {
                results = 'Error: request failed';
            } else {
                results = JSON.parse(response);
            }
            // Vue app
            payment = new Vue({
                el: '#payment',
                data: {
                    results: results,
                    amt: 0
                },
                computed: {
                    finishPayment: function() {
                        this.wow = [];
                        for (i = 0; i < this.results.length; i++) {
                            if (this.results[i].toPay == this.results[i].paid) {
                                this.wow.push(true);
                            } else {
                                this.wow.push(false);
                            }
                        }
                        return this.wow;
                    }
                }
            })
            ready();
        }
    })
}

// dashboard.html
if (window.location.href.includes("http://amcisa.org/form/dashboard.html")) {
    //number of orders
    $.ajax({
        type: 'GET',
        url: 'php/dashboardlist.php',
        data: { type: 'rowsmaincomm' },
        success: function(response) {
            if (response == "fail") {
                count = 'Error: request failed';
            } else {
                count = JSON.parse(response);
            }
            // Vue app
            total = new Vue({
                el: '#total',
                data: {
                    count: count[0][0]["COUNT(*)"],
                    recyclecount: count[1][0]["COUNT(*)"],
                    expprofit: 1500
                }
            })
        }
    })

    // recent 5 order ajax
    $.ajax({
        type: 'GET',
        url: 'php/dashboardlist.php',
        data: { type: 'purchase5' },
        success: function(response) {
            if (response == "fail") {
                results = 'Error: request failed';
            } else {
                results = JSON.parse(response);
            }
            // Vue app
            purchase = new Vue({
                el: '#purchase5',
                data: {
                    results: results
                },
                computed: {
                    notAmcisa: function() {
                        this.wow = [];
                        for (i = 0; i < this.results.length; i++) {
                            if (this.results[i].isAmcisa == 1) {
                                this.wow.push(true);
                            } else {
                                this.wow.push(false);
                            }
                        }
                        return this.wow;
                    },
                    isAnon: function() {
                        this.wowow = [];
                        for (i = 0; i < this.results.length; i++) {
                            if (this.results[i].isAnon == 1) {
                                this.wowow.push(true);
                            } else {
                                this.wowow.push(false);
                            }
                        }
                        return this.wowow;
                    },
                    completed: function() {
                        this.wowowow = [];
                        for (i = 0; i < this.results.length; i++) {
                            if (this.results[i].completed == 1) {
                                this.wowowow.push(true);
                            } else {
                                this.wowowow.push(false);
                            }
                        }
                        return this.wowowow;
                    },
                    hasRemarks: function() {
                        this.wowowowow = [];
                        for (i = 0; i < this.results.length; i++) {
                            if (this.results[i].remarks != '') {
                                this.wowowowow.push(true);
                            } else {
                                this.wowowowow.push(false);
                            }
                        }
                        return this.wowowowow;
                    }
                }
            })
            ready();
        }
    })
}

// purchaseorder.html
if (window.location.href.includes("http://amcisa.org/form/purchaseorder.html") || window.location.href.includes("http://amcisa.org/form/hall.html")) {
    // count rows
    $.ajax({
        type: 'GET',
        url: 'php/dashboardlist.php',
        data: { type: 'checkrows' },
        success: function(response) {
            if (response == "fail") {
                count = 'Error: request failed';
            } else {
                count = JSON.parse(response);
            }
            // Vue app
            links = new Vue({
                el: '#links',
                data: {
                    count: count[0]["COUNT(*)"]
                },
                computed: {
                    link: function() {
                        var tempcount = Math.floor(Number(this.count) / 20);
                        return tempcount + 1;
                    }
                }
            })
        }
    })

    // full order ajax
    if (type == 0) {
        $.ajax({
            type: 'GET',
            url: 'php/dashboardlist.php',
            data: { type: 'purchase', lowlim: lowlim },
            success: function(response) {
                if (response == "fail") {
                    results = 'Error: request failed';
                } else {
                    results = JSON.parse(response);
                }
                // Vue app
                purchase = new Vue({
                    el: '#purchase',
                    data: {
                        results: results,
                        lowlim: lowlim
                    },
                    computed: {
                        notAmcisa: function() {
                            this.wow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAmcisa == 1) {
                                    this.wow.push(true);
                                } else {
                                    this.wow.push(false);
                                }
                            }
                            return this.wow;
                        },
                        isAnon: function() {
                            this.wowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAnon == 1) {
                                    this.wowow.push(true);
                                } else {
                                    this.wowow.push(false);
                                }
                            }
                            return this.wowow;
                        },
                        completed: function() {
                            this.wowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].completed == 1) {
                                    this.wowowow.push(true);
                                } else {
                                    this.wowowow.push(false);
                                }
                            }
                            return this.wowowow;
                        },
                        hasRemarks: function() {
                            this.wowowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].remarks != '') {
                                    this.wowowowow.push(true);
                                } else {
                                    this.wowowowow.push(false);
                                }
                            }
                            return this.wowowowow;
                        }
                    }
                })
                ready();
            }
        })
    } else if (type == 'remarks') {
        // Show only remarks
        $('#links').addClass('hidden-xs-up');
        $('#remarksmode').addClass('hidden-xs-up');
        $('#normalmode').removeClass('hidden-xs-up');
        $.ajax({
            type: 'GET',
            url: 'php/dashboardlist.php',
            data: { type: 'remarks' },
            success: function(response) {
                if (response == "fail") {
                    results = 'Error: request failed';
                } else {
                    results = JSON.parse(response);
                }
                // Vue app
                purchase = new Vue({
                    el: '#purchase',
                    data: {
                        results: results
                    },
                    computed: {
                        notAmcisa: function() {
                            this.wow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAmcisa == 1) {
                                    this.wow.push(true);
                                } else {
                                    this.wow.push(false);
                                }
                            }
                            return this.wow;
                        },
                        isAnon: function() {
                            this.wowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAnon == 1) {
                                    this.wowow.push(true);
                                } else {
                                    this.wowow.push(false);
                                }
                            }
                            return this.wowow;
                        },
                        completed: function() {
                            this.wowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].completed == 1) {
                                    this.wowowow.push(true);
                                } else {
                                    this.wowowow.push(false);
                                }
                            }
                            return this.wowowow;
                        },
                        hasRemarks: function() {
                            this.wowowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].remarks != '') {
                                    this.wowowowow.push(true);
                                } else {
                                    this.wowowowow.push(false);
                                }
                            }
                            return this.wowowowow;
                        }
                    }
                })
                ready();
            }
        })
    } else if (type == 'hall') {
        // Show hall
        $.ajax({
            type: 'GET',
            url: 'php/dashboardlist.php',
            data: { type: 'hall', hall: hall },
            success: function(response) {
                if (response == "fail") {
                    results = 'Error: request failed';
                } else {
                    results = JSON.parse(response);
                }
                // Vue app
                halllist = new Vue({
                    el: '#halllist',
                    data: {
                        results: results
                    },
                    computed: {
                        notAmcisa: function() {
                            this.wow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAmcisa == 1) {
                                    this.wow.push(true);
                                } else {
                                    this.wow.push(false);
                                }
                            }
                            return this.wow;
                        },
                        isAnon: function() {
                            this.wowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAnon == 1) {
                                    this.wowow.push(true);
                                } else {
                                    this.wowow.push(false);
                                }
                            }
                            return this.wowow;
                        },
                        completed: function() {
                            this.wowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].completed == 1) {
                                    this.wowowow.push(true);
                                } else {
                                    this.wowowow.push(false);
                                }
                            }
                            return this.wowowow;
                        },
                        hasRemarks: function() {
                            this.wowowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].remarks != '') {
                                    this.wowowowow.push(true);
                                } else {
                                    this.wowowowow.push(false);
                                }
                            }
                            return this.wowowowow;
                        }
                    }
                })
                ready();
            }
        })
    }
}

// completedorder.html
if (window.location.href.includes("http://amcisa.org/form/completedorder.html")) {
    // count rows
    $.ajax({
        type: 'GET',
        url: 'php/dashboardlist.php',
        data: { type: 'checkcompletedrows' },
        success: function(response) {
            if (response == "fail") {
                count = 'Error: request failed';
            } else {
                count = JSON.parse(response);
            }
            // Vue app
            links = new Vue({
                el: '#links',
                data: {
                    count: count[0]["COUNT(*)"]
                },
                computed: {
                    link: function() {
                        var tempcount = Math.floor(Number(this.count) / 20);
                        return tempcount + 1;
                    }
                }
            })
        }
    })

    // full order ajax
    if (type == 0) {
        $.ajax({
            type: 'GET',
            url: 'php/dashboardlist.php',
            data: { type: 'completedpurchase', lowlim: lowlim },
            success: function(response) {
                if (response == "fail") {
                    results = 'Error: request failed';
                } else {
                    results = JSON.parse(response);
                }
                // Vue app
                purchase = new Vue({
                    el: '#purchase',
                    data: {
                        results: results,
                        lowlim: lowlim
                    },
                    computed: {
                        notAmcisa: function() {
                            this.wow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAmcisa == 1) {
                                    this.wow.push(true);
                                } else {
                                    this.wow.push(false);
                                }
                            }
                            return this.wow;
                        },
                        isAnon: function() {
                            this.wowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].isAnon == 1) {
                                    this.wowow.push(true);
                                } else {
                                    this.wowow.push(false);
                                }
                            }
                            return this.wowow;
                        },
                        completed: function() {
                            this.wowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].completed == 1) {
                                    this.wowowow.push(true);
                                } else {
                                    this.wowowow.push(false);
                                }
                            }
                            return this.wowowow;
                        },
                        hasRemarks: function() {
                            this.wowowowow = [];
                            for (i = 0; i < this.results.length; i++) {
                                if (this.results[i].remarks != '') {
                                    this.wowowowow.push(true);
                                } else {
                                    this.wowowowow.push(false);
                                }
                            }
                            return this.wowowowow;
                        }
                    }
                })
                ready();
            }
        })
    }
}