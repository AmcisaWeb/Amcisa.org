// Global variables

var toggle = {};
var confirmTick = {};
var query = {};
var userdata = {};
var danger = {};
var wordcount = {};
var address = {};
var naName = {};
var amcisaName = {};
for (i = 0; i < 100; i++) {
    toggle[i] = false;
    confirmTick[i] = false;
    danger[i] = false;
    query[i] = '';
    wordcount[i] = '';
    address[i] = '';
    naName[i] = '';
    amcisaName[i] = '';
};
$.ajax({
    type: 'POST',
    url: 'php/retrieve.php',
    success: function(response) {
        // Vue app
        app = new Vue({
            el: '#form',
            data: {
                formsection: 1,
                checked: "No, I have something that I want to change",
                check: "Yes, I confirm the above data is correct",
                notcheck: "No, I have something that I want to change",
                amount: 1,
                toggle: toggle,
                query: query,
                wordcount: wordcount,
                danger: danger,
                confirmTick: confirmTick,
                userdata: userdata,
                address: address,
                naName: naName,
                amcisaName: amcisaName,
                list: ['haha'],
                listCH: ['hahahaha']
            },
            computed: {
                items: function() {
                    this.wow = [];
                    for (i = 1; i <= this.amount; i++) {
                        this.wow.push(i + 1);
                    }
                    return this.wow
                }
            },
            methods: {
                OnSubmit: function () {
                    //KIMYONG EDIT
                    axios.defaults.baseURL = 'http://amcisa.org'
                    var axiosEvent = axios.create({
                        headers: {'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + localStorage.getItem('token') }
                    })
                    axiosEvent.post('/api/bobi', {
                        data: 'this is the data'
                    }).then(function (response) {
                        console.log(response)
                    }).catch(function (error) {
                        console.log(error.response)
                    })
                },
                computedList: function(item) {
                    var self = this;
                    return self.list.filter(function(name) {
                        return 'haha'
                        //return name.Name_EN.toLowerCase().indexOf(self.query[item].toLowerCase()) > -1
                        //KIMYONG EDIT
                    })
                },
                computedListCH: function(item) {
                    var self = this;
                    return self.listCH.filter(function(name) {
                        return 'haha'
                        //return name.Name_CH.indexOf(self.query[item]) > -1
                        //KIMYONG EDIT
                    })
                },
                confirming: function(item) {
                    confirmTick[item] = !confirmTick[item];
                    return
                },
                wordlimit: function(item) {
                    var placeholder = this.wordcount[item].valueOf()
                    if (placeholder.length >= 201) {
                        this.danger[item] = true
                        return
                    } else {
                        this.danger[item] = false
                        return
                    }
                },
                next: function(item) {
                    // validate input here
                    //KIMYONG EDIT
                    /*
                    if (this.toggle[item] == false && this.amcisaName[item] == '') {
                    if(true){
                        alert("Name is empty!");
                        return
                    } else if (this.toggle[item] == true && this.naName[item] == '') {
                        alert("Name is empty!");
                        return
                    } else if (this.toggle[item] == true && this.address[item] == '') {
                        alert("Address is empty!");
                        return
                    } else {
                        this.formsection += 1;
                        return
                    }
                    */
                    this.formsection += 1;
                }
            }
        })

        // Initialising form
        rpc(
            "../gh/php/login_delegate.php", {
                "action": "CHECKLOGINSTATUS"
            },
            function(data) {
                // If already login
                if (data != 0) {
                    userdata = JSON.parse(data);
                    $('#username').html(userdata.Name_EN);
                    $('#login').addClass('hidden-xs-up');
                    $('.mainbutton').removeClass('hidden-xs-up');
                    $('.loader').addClass('hidden-xs-up');
                    $('#form').removeClass('hidden-xs-up');
                }
                // Else
                else {
                    $('#login').removeClass('hidden-xs-up');
                    $('.mainbutton').addClass('hidden-xs-up');
                    $('.loader').addClass('hidden-xs-up');
                    $('#form').removeClass('hidden-xs-up');
                    $("#loginbtn").click(function(e) {
                        $("#loginbtn").html('Logging in...');
                        rpc(
                            "../gh/php/login_delegate.php", {
                                "action": "LOGIN",
                                "Matric_NO": $("#Matric_NO").val(),
                                "Password": $("#Password").val(),
                                "Reset": $("#checkboxhidden input.checkbox:checked").val(),
                            },
                            function(data) {
                                //KIMYONG EDIT
                                axios.defaults.baseURL = 'http://amcisa.org'
                                var axiosToken = axios.create({
                                    headers: {'Content-Type': 'application/json'}
                                })
                                axiosToken.post('/oauth/token', {
                                    grant_type: 'password',
                                    client_id: 1,
                                    client_secret: '656qdZkintJzWSBKaaipFnRQzmP2SVrmdTPafbU5',
                                    username: 'C170133@e.ntu.edu.sg',
                                    password: '222222'
                                }).then(function (response) {
                                    console.log(response)
                                    localStorage.setItem('token', response.data.access_token)
                                    window.location.href = 'purchases.php';
                                }).catch(function (error) {
                                    console.log(error.response)
                                })
                            }
                        )
                    })
                }
            }
        );
    }
})

// signout
function signOut() {
    rpc(
        "../gh/php/login_delegate.php", {
            "action": "LOGOUT"
        },
        function(data) {
            window.location.href = "index.html";
        }
    )
}