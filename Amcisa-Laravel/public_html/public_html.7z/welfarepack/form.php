<?php
	include("php/common.php");
	$_SESSION['matricnum'] = "U1520002D";
	if(empty($_SESSION['matricnum'])){
		header("Location: index.html");
		die();
	}
	//if(time() >= $submitdeadline && $_SESSION['matricnum'] != "U1520050L"){   //KIMYONG EDIT
	if(false){
    echo '<script>alert("The deadline for submission has passed.");window.location.href="purchases.php"</script>';
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Bobi包</title>
    <link rel="shortcut icon" href="pic/header.PNG">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/cover.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

    <!-- Font -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

    <div class="site-wrapper">

        <div class="site-wrapper-inner">

            <div class="loader"></div>

            <div id="form" class="cover-container hidden-xs-up">

                <div class="masthead clearfix">
                    <div class="inner">
                        <h3 class="masthead-brand"><a class="nav-link active" href="index.html">EWP</a></h3>
                        <nav class="nav nav-masthead">
                            <a id="username" class="nav-link active" href="purchases.php"></a>
                            <a class="mainbutton nav-link" onclick="signOut()">Logout</a>
                        </nav>
                    </div>
                </div>

                <div class="inner cover">
                    <h1 class="cover-heading"><img style="max-height: 150px" class="img-fluid" src="pic/index.PNG"></h1>
                    <p class="lead">Bobi包在手，A+随我走<br>FOA 1718 Fundraising</p>
                </div>

                <div class="inner form">
                    <form action="php/submit.php" method="post">
                        <div v-bind:class="{'animated bounceInLeft': formsection === 1}" v-show="formsection === 1" id="form_1" key="1">
                            <div class="form-group">
                                <h4>Step 1: How much do you want to buy?</h4>
                                <label for="amount">Amount</label>
                                <input name="amount" type="number" pattern="[0-9]*" min="1" max="100" class="form-control" id="amount" placeholder="Amount" v-model="amount">
                                <small class="form-text">Each pack costs $3</small>
                            </div>
                            <a class="btn btn-primary" v-on:click="formsection += 1">Next</a>
                        </div>
                        <template v-for="item in items">
                                <div v-bind:class="{ 'animated bounceInLeft': formsection === item}" v-show="formsection === item" v-bind:id="'form_'+item" v-bind:key="item">
                                    <h4>Step 2: Fill in recipient(s) details</h4>
                                    <br>
                                    <h5>Pack {{ item - 1 }} out of {{ amount }}</h5>
                                    <div class="form-check">
                                        <input v-bind:name="'isAmcisa'+item" type="checkbox" class="form-check-input" v-bind:id="'not_amcisa_'+item" v-model="toggle[item]">
                                        <label v-bind:for="'not_amcisa_'+item">Is this recipient not from Amcisa?</label>
                                    </div>
                                    <div v-if="!toggle[item]" v-bind:id="'is_amcisa_form_'+item" class="form-group">
                                        <label>Search and select from the dropdown list below:</label>
                                        <input v-show="!confirmTick[item]" type="text" class="form-control searchbar animated fadeIn" v-bind:id="'name_search_'+item" placeholder="Search for English/Chinese name 输入中/英文名字" v-model="query[item]">
                                        
                                        <div class="input-group">
                                            <select v-model="amcisaName[item]" v-bind:name="'amcisaName'+item" class="form-control" v-bind:id="'to_name_'+item" required>
                                                <option value="" disabled selected>Choose a name:</option>
                                                <option
                                                v-for="(name, index) in computedList(item)"
                                                v-bind:key="name"
                                                v-bind:data-index="index"
                                                >{{ name.Name_EN }}</option>
                                                <option
                                                v-for="(name, index) in computedListCH(item)"
                                                v-bind:key="name"
                                                v-bind:data-index="index"
                                                >{{ name.Name_CH }}</option>
                                            </select>

                                            <span class="input-group-btn">
                                                <button class="btn btn-secondary" type="button" v-on:click="confirming(item)">
                                                    <i v-show="!confirmTick[item]" class="fa fa-check animated tada" aria-hidden="true"></i>
                                                    <i v-show="confirmTick[item]" class="fa fa-pencil animated rubberBand" aria-hidden="true"></i>
                                                </button>
                                            </span>

                                        </div>
                                    </div>
                                    <div v-if="toggle[item]" v-bind:id="'not_amcisa_form_'+item">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input v-model="naName[item]" v-bind:name="'naName'+item" type="text" class="form-control" v-bind:id="'to_name_not_amcisa'+item" placeholder="Enter name (non Amcisa)" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea v-model="address[item]" v-bind:name="'naAddress'+item" class="form-control" v-bind:id="'to_address_not_amcisa'+item" rows="3" required></textarea>
                                        </div>
                                    </div>
                                    <div class="form-check">
                                        <input v-bind:name="'isAnon'+item" type="checkbox" class="form-check-input" v-bind:id="'isAnon'+item">
                                        <label v-bind:for="'isAnon'+item">Send Anonymously? 以匿名方式发送？</label>
                                    </div>
                                    <div v-bind:id="'to_text_div_'+item" v-bind:class="{'has-danger': danger[item]}">
                                        <label>What do you want to say to this recipient?</label>
                                        <textarea v-bind:name="'text'+item" class="form-control form-control-danger" v-model="wordcount[item]" v-bind:id="'to_text_'+item" rows="4" maxlength="201" v-bind:onkeyup="wordlimit(item)"></textarea>
                                        <small v-if="danger[item]" class="form-text text-muted">It's over 9000!<br>Word limit of 200 characters</small>
                                    </div>
                                    <div v-bind:id="'remarks_div_'+item">
                                        <br>
                                        <label>Any remarks?</label>
                                        <small class="form-text text-muted">eg. add custom greetings (From XXX...)</small>
                                        <textarea v-bind:name="'remarks'+item" class="form-control" v-bind:id="'remarks_'+item" rows="2"></textarea>
                                    </div>
                                    <a class="btn btn-primary" v-on:click="formsection -= 1">Previous</a>
                                    <a class="btn btn-primary" v-on:click="next(item)">Next</a>
                                </div>
                            </template>
                        <div v-bind:class="{ 'animated bounceInLeft': formsection === items[items.length-1] + 1}" v-show="formsection === items[items.length-1] + 1" id="form_last" key="last">
                            <h4>Step 3: Confirm your input</h4>
                            <p>
                                That's it! Remember that your purchase isn't yet done! Please submit your payment at the time and venue stated below:
                            </p>
                            <ul>
                                <li>Date: 24 March 2017</li>
                                <li>Time: Until 5 pm</li>
                                <li>Venue: SAC</li>
                            </ul>
                            <p>
                                Remember you can still edit the wishes you want to say to the recipient(s), or add on any remakrs after you have submitted until <strong>26 March</strong>. If you have any queries, feel free to contact the people below:
                            </p>
                            <ul>
                                <li>Gee Ann 卓己安（83981009）</li>
                                <li>Zi Hao 覃子豪（85580519）</li>
                                <li>Linges 林格斯（83678809）</li>
                                <li>Bing Sheng 锺秉声（83149248）[for website related queries]</li>
                            </ul>
                            <br>
                            <h5>
                                <strong>Confirm your purchase order and proceed to submit.</strong>
                            </h5>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" id="checkbox" v-model="checked" v-bind:true-value="check" v-bind:false-value="notcheck" required>
                                    <label for="checkbox">{{ checked }}</label>
                                </label>
                            </div>
                            <a class="btn btn-primary" v-on:click="formsection -= 1">Previous</a>
                            <button type="submit" class="btn btn-success" @click="OnSubmit">Submit</button>
                        </div>
                    </form>
                </div>

                <div class="mastfoot mobile">
                    <div class="inner">
                        <p><a href="http://amcisa.org/gh/index.html">Amcisa</a> 2017</p>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/vue.min.js"></script>
    <script src="../gh/js/util.js"></script>
    <script src="js/custom.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</body>

</html>