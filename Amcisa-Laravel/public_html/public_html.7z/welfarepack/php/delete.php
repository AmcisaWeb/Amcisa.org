<?php
    require('common.php');
    if(time() <= $submitdeadline || $_SESSION['matricnum'] === "U1520050L"){
        if(!empty($_SESSION['matricnum']) && !empty($_POST['id'])){
            // retrieve name and matric
            $matric = $_SESSION['matricnum'];
            $query = "SELECT Name_EN FROM memberlist WHERE Matric_NO = :matric";
            $query_params = array(
                ':matric' => $matric
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query".$i);
            }
            $row = $stmt->fetch();
            $name = ucwords(strtolower($row['Name_EN']));

            // delete entry
            function sanitize($in, $key){
                $in = trim($in);
                $in = filter_var($in, FILTER_SANITIZE_STRING);
                return $in;
            }
            $id = sanitize($_POST['id']);
            $query = "DELETE FROM foa_welfarepack_name WHERE id = :id";
            $query_params = array(
                ':id' => $id
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query".$i);
            };
            // Insert delete payment info
            $query = "
                INSERT INTO foa_welfarepack_payment (
                    Matric_NO,
                    name,
                    packs,
                    toPay,
                    collectedNo,
                    paid
                ) VALUES (
                    :Matric_NO,
                    :name,
                    :packs,
                    :toPay,
                    :collectedNo,
                    :paid
                )
            ";
            $query_params = array(
                ':Matric_NO' => $matric,
                ':name' => $name,
                ':packs' => -1,
                ':toPay' => -3,
                ':collectedNo' => 0,
                ':paid' => 0
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to insert payment");
            }
            echo 'done';
        } else {
            echo 'fail';
        }
    } else {
        echo 'timeup';
    }