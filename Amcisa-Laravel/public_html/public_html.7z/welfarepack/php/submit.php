<?php
    require('common.php');
    if(time() <= $submitdeadline || $_SESSION['matricnum'] === "U1520050L"){
        if(!empty($_POST))
        {
            // sanitize input
            function sanitize($in){
                $in = trim($in);
                $in = filter_var($in, FILTER_SANITIZE_STRING);
                return $in;
            }
            $array = [];
            foreach($_POST as $key => $value){
                $value = sanitize($value);
                $array[$key] = $value;
            }
            $_POST = $array;

            // Retrieve current user name
            $matric = $_SESSION['matricnum'];
            $query = "SELECT Name_EN FROM memberlist WHERE Matric_NO = :matric";
            $query_params = array(
                ':matric' => $matric
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query".$i);
            }
            $row = $stmt->fetch();
            $name = ucwords(strtolower($row['Name_EN']));
            $date = date('Y-m-d G:i:s');
            $packs = $_POST['amount'];
            $packs = (int)$packs;
            for ($i = 0; $i< $packs; $i++){
                $j = $i + 2;
                // Check if anon send
                if($_POST['isAnon'.$j] === 'on'){
                    $isAnon[$i] = 1;
                } else{
                    $isAnon[$i] = 0;
                }
                // Check if amcisa, then format and save the name and matric
                if($_POST['isAmcisa'.$j] === 'on'){
                    $isAmcisa[$i] = 1;
                }
                if(!empty($_POST['amcisaName'.$j])){
                    $toName[$i] = ucwords(strtolower($_POST['amcisaName'.$j]));
                    // get recipient matric no
                    $query = "SELECT Matric_NO FROM memberlist WHERE (Name_EN = :name OR Name_CH = :name)";
                    $query_params = array(
                        ':name' => $toName[$i]
                    );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $result = $stmt->execute($query_params);
                    }
                    catch(PDOException $ex)
                    {
                        die("Failed to run query".$i);
                    }
                    $matricResult = $stmt->fetch();
                    $toMatric[$i] = $matricResult['Matric_NO'];
                } else {
                    $toName[$i]= ucwords(strtolower($_POST['naName'.$j]));
                    $address[$i] = $_POST['naAddress'.$j];
                    $toMatric[$i] = '';
                }
                // Check if text empty
                if (empty($_POST['text'.$j])) {
                    $toText[$i] = '';
                } else {
                    $toText[$i] = $_POST['text'.$j];
                }
                // Check if remark empty
                if (empty($_POST['remarks'.$j])) {
                    $remarks[$i] = '';
                } else {
                    $remarks[$i] = $_POST['remarks'.$j];
                }
            }

            // Inserting one to one relationship
            for ($i = 0; $i< $packs; $i++){
                $query = "
                    INSERT INTO foa_welfarepack_name (
                        Matric_NO,
                        name,
                        packs,
                        toName,
                        toText,
                        date,
                        toMatric,
                        remarks,
                        isAnon";
                if($isAmcisa[$i] === 1){
                    $query .= ", isAmcisa, address";
                }
                $query .="
                    ) VALUES (
                        :Matric_NO,
                        :name,
                        :packs,
                        :toName,
                        :toText,
                        :date,
                        :toMatric,
                        :remarks,
                        :isAnon";
                if($isAmcisa[$i] === 1){
                    $query .= ", :isAmcisa, :address";
                }
                $query .= "
                    )
                ";
                $query_params = array(
                    ':toMatric' => $toMatric[$i],
                    ':Matric_NO' => $matric,
                    ':name' => $name,
                    ':packs' => $packs,
                    ':toName' => $toName[$i],
                    ':toText' => $toText[$i],
                    ':date' => $date,
                    ':remarks' => $remarks[$i],
                    ':isAnon' => $isAnon[$i]
                );
                if($isAmcisa[$i] === 1){
                    $query_params[':isAmcisa'] = $isAmcisa[$i];
                    $query_params[':address'] = $address[$i];
                }

                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die($ex);
                }
            }

            // Inserting payment item
            $price = 3;
            $toPay = $packs * $price;
            $collectedNo = 0;
            $paid = 0;
            // creating user
            $query = "
                INSERT INTO foa_welfarepack_payment (
                    Matric_NO,
                    name,
                    packs,
                    toPay,
                    collectedNo,
                    paid
                ) VALUES (
                    :Matric_NO,
                    :name,
                    :packs,
                    :toPay,
                    :collectedNo,
                    :paid
                )
            ";
            $query_params = array(
                ':Matric_NO' => $matric,
                ':name' => $name,
                ':packs' => $packs,
                ':toPay' => $toPay,
                ':collectedNo' => $collectedNo,
                ':paid' => $paid
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to insert payment");
            }
            echo '<script>alert("Thank you for your purchase! Remember to submit your payment!");window.location.href="../purchases.php";</script>';
            die();
        }
    } else {
        echo '<script>alert("The deadline for submission has passed.");window.location.href="../index.html"</script>';
    }