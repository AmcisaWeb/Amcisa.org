<?php
    require('common.php');
	if(!empty($_SESSION['matricnum'])){
		$matric = $_SESSION['matricnum'];
		$query = "SELECT * FROM foa_welfarepack_name WHERE Matric_NO = :matric ORDER BY id";
        $query_params = array(
            ':matric' => $matric
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query".$i);
        }
        $rows = $stmt->fetchAll();
		echo json_encode($rows);
	} else {
		echo 'fail';
	}