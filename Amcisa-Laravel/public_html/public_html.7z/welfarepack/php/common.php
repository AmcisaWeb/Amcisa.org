<?php
    // Connection information for MySQL database 
    //KIMYONG EDIT