<?php
    require('common.php');
    if(time() <= $editdeadline){
        if(!empty($_SESSION['matricnum']) && !empty($_POST)){
            // sanitize input
            function sanitize($in){
                $in = trim($in);
                $in = filter_var($in, FILTER_SANITIZE_STRING);
                return $in;
            }
            $array = [];
            foreach($_POST as $key => $value){
                $value = sanitize($value);
                $array[$key] = $value;
            }
            $_POST = $array;

            $toText = $_POST['text'];
            if (empty($_POST['remarks'])){
                $remarks = '';
            } else {
                $remarks = $_POST['remarks'];
            }
            if ($_POST['isAnon'] === 'on'){
                $isAnon = 1;
            } else {
                $isAnon = 0;
            }
            $id = $_POST['id'];
            $query = "UPDATE foa_welfarepack_name SET toText = :toText, isAnon = :isAnon, remarks = :remarks WHERE id = :id";
            $query_params = array(
                ':toText' => $toText,
                ':id' => $id,
                ':remarks' => $remarks,
                ':isAnon' => $isAnon
            );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die($ex);
            }
            echo '<script>alert("Successfully edited.");window.location.href="../purchases.php";</script>';
        } else {
            echo 'fail';
        }
    } else {
        echo '<script>alert("The deadline for submission has passed.");window.location.href="../index.html"</script>';
    }