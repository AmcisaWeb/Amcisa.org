<?php
    require('common.php');
    switch($_GET['type']){
        case 'rowsmaincomm':
            $query = "SELECT COUNT(*) FROM foa_welfarepack_name";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows1 = $stmt->fetchAll();
            $query="SELECT COUNT(*) FROM foa_welfarepack_name WHERE toMatric = 'U1522787D' OR toMatric = 'U1440011F' OR toMatric = 'U1440109H' OR toMatric = 'U1530050D' OR toMatric = 'U1530003E' OR toMatric = 'U1530034G' OR toMatric = 'U1523044K' OR toMatric = 'U1520050L' OR toMatric = 'U1540014D' OR toMatric = 'U1520040B' OR toMatric = 'U1520013K' OR toMatric = 'U1530015H' OR toMatric = 'U1523049F' OR toMatric = 'U1520020F' OR toMatric = 'U1521390A' OR toMatric = 'U1520003A' OR toMatric = 'U1620031H' OR toMatric = 'U1540995C' OR toMatric = 'U1520008H' OR toMatric = 'U1540040K' OR toMatric = 'U1540061C' OR toMatric = 'U1530045B' OR toMatric = 'U1520048L' OR toMatric = 'U1530005K'";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows2 = $stmt->fetchAll();
            $rows[0] = $rows1;
            $rows[1] = $rows2;
            echo json_encode($rows);
            break;
        case 'checkrows':
            $query = "SELECT COUNT(*) FROM foa_welfarepack_name";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            break;
        case 'purchase':
            if (!empty($_GET['lowlim'])){
                function sanitize($in){
                    $in = trim($in);
                    $in = filter_var($in, FILTER_SANITIZE_STRING);
                    return $in;
                }
                foreach($_GET as $key => $value){
                    $value = sanitize($value);
                    $array[$key] = $value;
                }
                $_GET = $array;
                $lowlim = sanitize($_GET['lowlim']);
            } else {
                $lowlim = 0;
            }
            //retrieve purchase one to one list
            $query = "SELECT * FROM foa_welfarepack_name ORDER BY name LIMIT ".$lowlim.",20";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            $tempindex = 0;
            foreach ($rows as $row){
                if(empty($row['address'])){
                    $matric = $row['toMatric'];
                    $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                    $query_params=array(
                        ':matric' => $matric
                    );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $stmt->execute($query_params);
                    }
                    catch(PDOException $ex)
                    {
                        die("Failed to run query");
                    }
                    $memberAddressArray = $stmt->fetch();
                    if($memberAddressArray['Hall'] == 'outside'){
                        $memberAddress = $memberAddressArray['Address_Outside'];
                    } else {
                        $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                    }
                    $rows[$tempindex]['address'] = $memberAddress;
                    $rows[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
                }
                $tempindex++;
            }
            echo json_encode($rows);
            break;
        case 'remarks':
            //retrieve purchase one to one list
            $query = "SELECT * FROM foa_welfarepack_name WHERE remarks != ''";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            $tempindex = 0;
            foreach ($rows as $row){
                if(empty($row['address'])){
                    $matric = $row['toMatric'];
                    $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                    $query_params=array(
                        ':matric' => $matric
                    );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $stmt->execute($query_params);
                    }
                    catch(PDOException $ex)
                    {
                        die("Failed to run query");
                    }
                    $memberAddressArray = $stmt->fetch();
                    if($memberAddressArray['Hall'] == 'outside'){
                        $memberAddress = $memberAddressArray['Address_Outside'];
                    } else {
                        $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                    }
                    $rows[$tempindex]['address'] = $memberAddress;
                    $rows[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
                }
                $tempindex++;
            }
            echo json_encode($rows);
            break;
        case 'hall':
            if (!empty($_GET['hall'])){
                $hall = $_GET['hall'];
            } else {
                $hall = 0;
            }
            //retrieve purchase one to one list sorted by hall
            $query = "SELECT 
                foa_welfarepack_name.id,
                foa_welfarepack_name.Matric_NO,
                foa_welfarepack_name.name,
                foa_welfarepack_name.isAnon,
                foa_welfarepack_name.packs,
                foa_welfarepack_name.isAmcisa,
                foa_welfarepack_name.toName,
                foa_welfarepack_name.toMatric,
                foa_welfarepack_name.toText,
                foa_welfarepack_name.address,
                foa_welfarepack_name.date,
                foa_welfarepack_name.remarks,
                foa_welfarepack_name.completed,
                memberlist.Phone_SG,
                memberlist.Hall,
                memberlist.Block,
                memberlist.Level,
                memberlist.Room,
                memberlist.Address_Outside
                FROM foa_welfarepack_name JOIN memberlist ON foa_welfarepack_name.toMatric = memberlist.Matric_NO AND memberlist.Hall = :hall ORDER BY memberlist.Block";
            $query_params=array(
                ':hall' => $hall
            );
            try
            {
                $stmt = $db->prepare($query);
                $stmt->execute($query_params);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            break;
        case 'purchase5':
            //retrieve purchase one to one list
            $query = "SELECT * FROM foa_welfarepack_name ORDER BY date DESC LIMIT 5";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query".$i);
            }
            $rows = $stmt->fetchAll();
            $tempindex = 0;
            foreach ($rows as $row){
                if(empty($row['address'])){
                    $matric = $row['toMatric'];
                    $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                    $query_params=array(
                        ':matric' => $matric
                    );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $stmt->execute($query_params);
                    }
                    catch(PDOException $ex)
                    {
                        die("Failed to run query");
                    }
                    $memberAddressArray = $stmt->fetch();
                    if($memberAddressArray['Hall'] == 'outside'){
                        $memberAddress = $memberAddressArray['Address_Outside'];
                    } else {
                        $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                    }
                    $rows[$tempindex]['address'] = $memberAddress;
                    $rows[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
                }
                $tempindex++;
            }
            echo json_encode($rows);
            break;
        case 'payment':
            // retrieve payment status list
            $query = "SELECT * FROM foa_welfarepack_payment ORDER BY name";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query".$i);
            }
            $rows = $stmt->fetchAll();
            // Create temporary array
            // Loop through each row in database
            foreach ($rows as $row){
                $counter = 0;
                $repeatcounter = 0;
                // Loop through each row in temparray
                foreach ($temparray as $temprow){
                    if ($temprow['name'] == $row['name']){
                        // row already exist in temparray, add up payment info
                        $temprow['packs'] += $row['packs'];
                        $temprow['toPay'] += $row['toPay'];
                        $temprow['collectedNo'] += $row['collectedNo'];
                        $temprow['paid'] += $row['paid'];
                        if($row['approvedByName'] != ''){$temprow['approvedByName'] = $row['approvedByName'];}
                        if($row['approvedByMatric'] != ''){$temprow['approvedByMatric'] = $row['approvedByMatric'];}
                        // save into temparray
                        $temparray[$repeatcounter] = $temprow;
                        break;
                    } else {
                        $counter ++;
                    }
                    $repeatcounter ++;
                }
                if ($counter == count($temparray)){
                    // row does not exist in temparray, add new row
                    $temparray[] = $row;
                }
            }
            echo json_encode($temparray);
            break;
        case 'insertPayment':
            if (!empty($_POST)){
                // insert payment
                // sanitize input
                function sanitize($in){
                    $in = trim($in);
                    $in = filter_var($in, FILTER_SANITIZE_STRING);
                    return $in;
                }
                foreach($_POST as $key => $value){
                    $value = sanitize($value);
                    $array[$key] = $value;
                }
                $_POST = $array;
                $Matric_NO = $_POST['Matric_NO'];
                $name = $_POST['name'];
                $packs = 0;
                $toPay = 0;
                $collectedNo = $_POST['paid'] / 3;
                $paid = $_POST['paid'];
                $approvedByMatric = $_SESSION['matricnum'];
                $query = "SELECT Name_EN FROM memberlist WHERE Matric_NO = :matric";
                $query_params = array(
                    ':matric' => $approvedByMatric
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                $row = $stmt->fetch();
                $approvedByName = ucwords(strtolower($row['Name_EN']));
                
                $query = "INSERT INTO foa_welfarepack_payment (Matric_NO, name, packs, toPay, collectedNo, paid, approvedByName, approvedByMatric) VALUES (:Matric_NO, :name, :packs, :toPay, :collectedNo, :paid, :approvedByName, :approvedByMatric)";
                $query_params = array(
                    ':Matric_NO' => $Matric_NO,
                    ':name' => $name,
                    ':packs' => $packs,
                    ':toPay' => $toPay,
                    ':collectedNo' => $collectedNo,
                    ':paid' => $paid,
                    ':approvedByName' => $approvedByName,
                    ':approvedByMatric' => $approvedByMatric
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                echo 'done';
            } else {
                echo 'fail';
            }
            break;
        case 'complete':
            if (!empty($_POST)){
                // complete order
                // sanitize input
                function sanitize($in){
                    $in = trim($in);
                    $in = filter_var($in, FILTER_SANITIZE_STRING);
                    return $in;
                }
                foreach($_POST as $key => $value){
                    $value = sanitize($value);
                    $array[$key] = $value;
                }
                $_POST = $array;
                $id = $_POST['id'];
                
                $query = "UPDATE foa_welfarepack_name SET completed = 1 WHERE id = :id";
                $query_params = array(
                    ':id' => $id
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                echo 'done';
            } else {
                echo 'fail';
            }
            break;
        case 'uncomplete':
            if (!empty($_POST)){
                // complete order
                // sanitize input
                function sanitize($in){
                    $in = trim($in);
                    $in = filter_var($in, FILTER_SANITIZE_STRING);
                    return $in;
                }
                foreach($_POST as $key => $value){
                    $value = sanitize($value);
                    $array[$key] = $value;
                }
                $_POST = $array;
                $id = $_POST['id'];
                
                $query = "UPDATE foa_welfarepack_name SET completed = 0 WHERE id = :id";
                $query_params = array(
                    ':id' => $id
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                echo 'done';
            } else {
                echo 'fail';
            }
            break;
        case 'checkcompletedrows':
            $query = "SELECT COUNT(*) FROM foa_welfarepack_name WHERE completed = 1";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            break;
        case 'completedpurchase':
            if (!empty($_GET['lowlim'])){
                function sanitize($in){
                    $in = trim($in);
                    $in = filter_var($in, FILTER_SANITIZE_STRING);
                    return $in;
                }
                foreach($_GET as $key => $value){
                    $value = sanitize($value);
                    $array[$key] = $value;
                }
                $_GET = $array;
                $lowlim = sanitize($_GET['lowlim']);
            } else {
                $lowlim = 0;
            }
            //retrieve purchase one to one list
            $query = "SELECT * FROM foa_welfarepack_name WHERE completed = 1 ORDER BY name LIMIT ".$lowlim.",20";
            try
            {
                $stmt = $db->query($query);
            }
            catch(PDOException $ex)
            {
                die("Failed to run query");
            }
            $rows = $stmt->fetchAll();
            $tempindex = 0;
            foreach ($rows as $row){
                if(empty($row['address'])){
                    $matric = $row['toMatric'];
                    $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                    $query_params=array(
                        ':matric' => $matric
                    );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $stmt->execute($query_params);
                    }
                    catch(PDOException $ex)
                    {
                        die("Failed to run query");
                    }
                    $memberAddressArray = $stmt->fetch();
                    if($memberAddressArray['Hall'] == 'outside'){
                        $memberAddress = $memberAddressArray['Address_Outside'];
                    } else {
                        $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                    }
                    $rows[$tempindex]['address'] = $memberAddress;
                    $rows[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
                }
                $tempindex++;
            }
            echo json_encode($rows);
            break;
        default:
            // does not fit
            echo 'fail';
            break;
    }