<?php
	session_start();
	$_SESSION['matricnum'] = "U1520002D";
	if(empty($_SESSION['matricnum'])){
		header("Location: index.html");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Bobi包</title>
    <link rel="shortcut icon" href="pic/header.PNG">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/cover.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

    <!-- Font -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

    <div class="site-wrapper">

        <div class="site-wrapper-inner">

            <div class="loader"></div>

            <div id="form" class="cover-container hidden-xs-up">

                <div class="masthead clearfix">
                    <div class="inner">
                        <h3 class="masthead-brand"><a class="nav-link active" href="index.html">EWP</a></h3>
                        <nav class="nav nav-masthead">
                            <a id="username" class="nav-link active" href="purchases.php"></a>
                            <a class="mainbutton nav-link" onclick="signOut()">Logout</a>
                        </nav>
                    </div>
                </div>

                <div class="inner cover">
                    <h1 class="cover-heading"><img style="max-height: 150px" class="img-fluid" src="pic/index.PNG"></h1>
                    <p class="lead">Bobi包在手，A+随我走<br>FOA 1718 Fundraising</p>
                </div>
                <p>Check your purchases here.</p>
                <p>LAST CHANCE! The deadline for purchases and payment is:</p>
                <ul>
                    <li>Date: 24 March 2017</li>
                    <li>Time: Until 5 pm</li>
                    <li>Please pay at SAC</li>
                </ul>
                <p><br>Click the name to edit your wishes, add remarks or send it anonymously.
                <br>You are allowed to make any changes to your order until 26/3/2017 7pm.</p>
                <div class="inner form">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-inverse" id="table">
                            <thead>
                                <tr>
                                <th>#</th>
                                <th><center>Name</center></th>
                                <th><center>Time of Purchase</center></th>
                                <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <template v-for="(result, index) in results">
                                    <tr>
                                        <th scope="row">{{ index + 1 }}</th>
                                        <td><a v-bind:href="'edit.php?id='+result.id">{{ result.toName }}</a></td>
                                        <td>{{ result.date }}</td>
                                        <td>
                                            <button type="button" class="btn btn-outline-danger btn-sm" v-bind:onclick="'deleteitem('+result.id+')'">Delete</button>
                                        </td>
                                    </tr>
                                </template>
                                    <tr>
                                        <th scope="row"></th>
                                        <td></td>
                                        <td></td>
                                        <td><a href="form.php" type="button" class="btn btn-secondary">New order</a></td>
                                    </tr>
                            </tbody>
                        </table>
                    </div>
                    <small>Please <a href="">refresh</a> if the list is empty.</small>
                </div>
                
                <div class="mastfoot mobile">
                    <div class="inner">
                        <p><a href="http://amcisa.org/gh/index.html">Amcisa</a> 2017</p>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/vue.min.js"></script>
    <script src="../gh/js/util.js"></script>
    <script src="js/purchases.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
</body>

</html>