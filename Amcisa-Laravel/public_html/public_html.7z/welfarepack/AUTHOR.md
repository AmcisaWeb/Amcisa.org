Created by: CHONG BING SHENG
Date: 20/3/2017
Dependencies: login.js, util.js from amcisa.org/gh/js
    and its dependencies
    everything else is self contained