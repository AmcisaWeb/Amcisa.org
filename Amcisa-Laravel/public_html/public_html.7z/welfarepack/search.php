<?php
    require('php/common.php');
    if(!empty($_GET)){
        // sanitize input
        function sanitize($in){
            $in = trim($in);
            $in = filter_var($in, FILTER_SANITIZE_STRING);
            return $in;
        }
        foreach($_GET as $key => $value){
            $value = sanitize($value);
            $array[$key] = $value;
        }
        $_GET = $array;
        $name = '%'.$_GET['query'].'%';
        //retrieve purchase one to one list
        $query = "SELECT * FROM foa_welfarepack_name WHERE toName LIKE :name";
        $query_params=array(
            ':name' => $name
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query");
        }
        $rows = $stmt->fetchAll();
        $tempindex = 0;
        foreach ($rows as $row){
            if(empty($row['address'])){
                $matric = $row['toMatric'];
                $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                $query_params=array(
                    ':matric' => $matric
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                $memberAddressArray = $stmt->fetch();
                if($memberAddressArray['Hall'] == 'outside'){
                    $memberAddress = $memberAddressArray['Address_Outside'];
                } else {
                    $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                }
                $rows[$tempindex]['address'] = $memberAddress;
                $rows[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
            }
            $tempindex++;
        }
        //retrieve purchase one to one list from matric number
        // Retrieve matric number
        $query = "SELECT Matric_NO FROM memberlist WHERE Name_CH = :name OR Name_EN = :name";
        $query_params = array(
            ':name' => $_GET['query']
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query".$i);
        }
        $matric = $stmt->fetch();

        $query = "SELECT * FROM foa_welfarepack_name WHERE toMatric = :matric";
        $query_params=array(
            ':matric' => $matric['Matric_NO']
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query");
        }
        $rows1 = $stmt->fetchAll();
        $tempindex = 0;
        foreach ($rows1 as $row1){
            if(empty($row1['address'])){
                $matric = $row1['toMatric'];
                $query = "SELECT Phone_SG, Hall, Block, Level, Room, Address_Outside FROM memberlist WHERE Matric_NO = :matric";
                $query_params=array(
                    ':matric' => $matric
                );
                try
                {
                    $stmt = $db->prepare($query);
                    $stmt->execute($query_params);
                }
                catch(PDOException $ex)
                {
                    die("Failed to run query");
                }
                $memberAddressArray = $stmt->fetch();
                if($memberAddressArray['Hall'] == 'outside'){
                    $memberAddress = $memberAddressArray['Address_Outside'];
                } else {
                    $memberAddress = 'Hall '.$memberAddressArray['Hall'].', '.$memberAddressArray['Block'].'-'.$memberAddressArray['Level'].'-'.$memberAddressArray['Room'];
                }
                $rows1[$tempindex]['address'] = $memberAddress;
                $rows1[$tempindex]['Phone_SG'] = $memberAddressArray['Phone_SG'];
            }
            $tempindex++;
        }
    }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="pic/header.PNG">

        <title>Bobi包 Dashboard</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/dashboard.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">

        <!-- Font -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>

    <body>
        <nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse">
            <button class="navbar-toggler navbar-toggler-right hidden-lg-up" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
            <a class="navbar-brand" href="#">A+ Bobi包</a>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.html">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">Main Site</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="purchaseorder.html">Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="completedorder.html">Completed Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="paymentinfo.html">Payment</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="search.php">Search<span class="sr-only">(current)</span></a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <nav class="col-sm-3 col-md-2 hidden-xs-down bg-faded sidebar">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.html">Overview </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="purchaseorder.html">Orders</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="completedorder.html">Completed Orders</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="paymentinfo.html">Payment</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="search.php">Search <span class="sr-only">(current)</span></a>
                        </li>
                    </ul>
                </nav>


                <main class="col-sm-9 offset-sm-3 col-md-10 offset-md-2 pt-3">
                    <h1>Search</h1>

                    <h2>Search for name:</h2>
                    <form>
                        <div class="form-group" id="search">
                            <input id="query" name="query" type="text" class="form-control" placeholder="Enter recipient name" required>
                            <br>
                            <button type="submit" class="btn btn-info btn-lg btn-block">Search</button>
                        </div>
                    </form>
                    <h2>Result</h2>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Matric Number</th>
                                    <th>Purchaser name</th>
                                    <th>Anon send</th>
                                    <th>Non Amcisa</th>
                                    <th>Recipient matric</th>
                                    <th>Recipient name</th>
                                    <th>Recipient phone</th>
                                    <th>Wishes</th>
                                    <th>Address</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($rows as $row){ ?>
                                <?php if($row['completed'] == 0){ ?>
                                <tr class="<?php if($row['remarks'] != ''){echo 'table-info';} ?>">
                                    <th scope="row"><?php echo $row['id']; ?></th>
                                    <td><?php echo $row['date']; ?></td>
                                    <td><?php echo $row['Matric_NO']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><i class="fa <?php if($row['isAnon'] != 0){echo 'fa-check';}else{echo 'fa-times';} ?>" aria-hidden="true"></i></td>
                                    <td><i class="fa <?php if($row['isAmcisa'] != 0){echo 'fa-check';}else{echo 'fa-times';} ?>" aria-hidden="true"></i></td>
                                    <td><?php echo $row['toMatric']; ?></td>
                                    <td><?php echo $row['toName']; ?></td>
                                    <td><?php echo $row['Phone_SG']; ?></td>
                                    <td><span class="full"><?php echo $row['toText']; ?></span><span class="mobile">*hidden*</span></td>
                                    <td><?php echo $row['address']; ?></td>
                                    <td><?php echo $row['remarks']; ?></td>
                                    <td><button type="button" class="btn btn-outline-success btn-sm" onclick="complete(<?php echo $row['id']; ?>)">Complete</button></td>
                                </tr>
                                <?php } ?>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <br>
                    <h2>Entries with same Matric Number</h2>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Matric Number</th>
                                    <th>Purchaser name</th>
                                    <th>Anon send</th>
                                    <th>Non Amcisa</th>
                                    <th>Recipient matric</th>
                                    <th>Recipient name</th>
                                    <th>Recipient phone</th>
                                    <th>Wishes</th>
                                    <th>Address</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($rows1 as $row1){ ?>
                                <?php if($row1['completed'] == 0){ ?>
                                <tr class="<?php if($row1['remarks'] != ''){echo 'table-info';} ?>">
                                    <th scope="row"><?php echo $row1['id']; ?></th>
                                    <td><?php echo $row1['date']; ?></td>
                                    <td><?php echo $row1['Matric_NO']; ?></td>
                                    <td><?php echo $row1['name']; ?></td>
                                    <td><i class="fa <?php if($row1['isAnon'] != 0){echo 'fa-check';}else{echo 'fa-times';} ?>" aria-hidden="true"></i></td>
                                    <td><i class="fa <?php if($row1['isAmcisa'] != 0){echo 'fa-check';}else{echo 'fa-times';} ?>" aria-hidden="true"></i></td>
                                    <td><?php echo $row1['toMatric']; ?></td>
                                    <td><?php echo $row1['toName']; ?></td>
                                    <td><?php echo $row1['Phone_SG']; ?></td>
                                    <td><span class="full"><?php echo $row1['toText']; ?></span><span class="mobile">*hidden*</span></td>
                                    <td><?php echo $row1['address']; ?></td>
                                    <td><?php echo $row1['remarks']; ?></td>
                                    <td><button type="button" class="btn btn-outline-success btn-sm" onclick="complete(<?php echo $row1['id']; ?>)">Complete</button></td>
                                </tr>
                                <?php } ?>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        </div>

        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
        <script>
            window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/dashboard.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="js/ie10-viewport-bug-workaround.js"></script>
    </body>

    </html>