<?php
	session_start();
	if(empty($_SESSION['matricnum'])){
		header("Location: index.html");
		die();
	}
    if(empty($_GET['id'])){
		header("Location: purchases.php");
		die();
	} else {
        function sanitize($in, $key){
            $in = trim($in);
            $in = filter_var($in, FILTER_SANITIZE_STRING);
            return $in;
        }
        $id = sanitize($_GET['id']);
        require('php/common.php');
        $query = "SELECT toName, toText, remarks, isAnon FROM foa_welfarepack_name WHERE id = :id";
        $query_params = array(
            ':id' => $id
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query".$i);
        }
        $textresult = $stmt->fetch();
        $text = $textresult['toText'];
        $remarks = $textresult['remarks'];
        $isAnon = $textresult['isAnon'];
        $name = $textresult['toName'];
    }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="">

        <title>Bobi包</title>
        <link rel="shortcut icon" href="pic/header.PNG">

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/cover.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">

        <!-- Font -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>

    <body>

        <div class="site-wrapper">

            <div class="site-wrapper-inner">

                <div class="loader"></div>

                <div id="form" class="cover-container hidden-xs-up">

                    <div class="masthead clearfix">
                        <div class="inner">
                            <h3 class="masthead-brand"><a class="nav-link active" href="index.html">EWP</a></h3>
                            <nav class="nav nav-masthead">
                                <a id="username" class="nav-link active" href="purchases.php"></a>
                                <a class="mainbutton nav-link" onclick="signOut()">Logout</a>
                            </nav>
                        </div>
                    </div>

                    <div class="inner cover">
                        <h1 class="cover-heading"><img style="max-height: 150px" class="img-fluid" src="pic/index.PNG"></h1>
                        <p class="lead">Bobi包在手，A+随我走<br>FOA 1718 Fundraising</p>
                    </div>

                    <div class="inner form">
                        <form action="php/update.php" method="post">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input name="isAnon" type="checkbox" class="form-check-input" <?php if($isAnon == 1){echo 'checked';} ?>>
                                    Send Anonymously? 以匿名方式发送？
                                </label>
                            </div>
                            <div id="textwrap" class="form-group">
                                <label>What do you want to say to <strong><?php echo $name; ?></strong>?</label>
                                <textarea name="text" class="form-control form-control-danger" id="to_text" rows="4" maxlength="201"><?php echo $text; ?></textarea>
                                <small class="form-text text-muted hidden-xs-up">It's over 9000!<br>Word limit of 200 characters</small>
                            </div>
                            <div id="textwrap" class="form-group">
                                <label>Any remarks?</label>
                                <textarea name="remarks" class="form-control" id="remarks" rows="2"><?php echo $remarks; ?></textarea>
                            </div>
                            <input name="id" type="text" class="hidden-xs-up" value="<?php echo $id; ?>">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" required>
                                    Confirm change
                                </label>
                            </div>
                            <a href="purchases.php" class="btn btn-primary">Back</a>
                            <button type="submit" class="btn btn-success">Update</button>
                        </form>
                    </div>

                    <div class="mastfoot mobile">
                        <div class="inner">
                            <p><a href="http://amcisa.org/gh/index.html">Amcisa</a> 2017</p>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/vue.min.js"></script>
        <script src="../gh/js/util.js"></script>
        <script src="js/custom.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="js/ie10-viewport-bug-workaround.js"></script>
    </body>

    </html>